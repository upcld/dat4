// > Creator: Danz
// > Plugin: pinterest.js
// > Fungsi: Mencari gambar di Pinterest berdasarkan query dan mengirim 1 gambar berbeda dari sebelumnya
// > Akses: Semua pengguna
// > Format: .pinterest <query> atau .pin <query>

const axios = require('axios');

// Objek untuk menyimpan riwayat ID pin yang sudah dikirim per query
const sentPins = {};

let handler = async (m, { conn, text }) => {
  if (!text) return m.reply('> ☘️ *Masukkan kata kunci pencarian!*\nContoh: *.pinterest kucing lucu*');

  m.reply('> ☘️ *Sedang mencari gambar di Pinterest...*');

  try {
    const response = await axios.get(`https://izumiiiiiiii.dpdns.org/search/pinterest?query=${encodeURIComponent(text)}`, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36',
      },
      timeout: 10000,
    });

    const data = response.data;
    if (!data.status || !data.result.pins || data.result.pins.length === 0) {
      return m.reply('> ☘️ *Tidak ditemukan gambar untuk pencarian ini!*');
    }

    const pins = data.result.pins;

    // Inisialisasi riwayat untuk query ini jika belum ada
    if (!sentPins[text.toLowerCase()]) {
      sentPins[text.toLowerCase()] = [];
    }

    // Filter pin yang belum dikirim
    const availablePins = pins.filter(pin => !sentPins[text.toLowerCase()].includes(pin.id));
    if (availablePins.length === 0) {
      // Reset riwayat jika semua pin sudah dikirim
      sentPins[text.toLowerCase()] = [];
      m.reply('> ☘️ *Semua gambar untuk query ini sudah dikirim sebelumnya. Mengulang dari awal...*');
    }

    // Pilih pin pertama dari pin yang tersedia
    const selectedPin = availablePins[0] || pins[0]; // Fallback ke pin pertama jika riwayat direset
    const imageUrl = selectedPin.media.images.large.url;
    const pinId = selectedPin.id;

    // Tambahkan ID pin ke riwayat
    sentPins[text.toLowerCase()].push(pinId);

    const caption = `> ☘️ *Hasil Pencarian Pinterest: ${text}*\n\n` +
                    `Judul: ${selectedPin.title || 'Tanpa judul'}\n` +
                    `Deskripsi: ${selectedPin.description || 'Tanpa deskripsi'}\n` +
                    `URL: ${selectedPin.pin_url}\n` +
                    `Diupload oleh: ${selectedPin.uploader.full_name} (@${selectedPin.uploader.username})`;

    await conn.sendMessage(m.chat, { image: { url: imageUrl }, caption }, { quoted: m });

  } catch (e) {
    console.error(e);
    let errorMessage = e.message;
    if (e.code === 'ECONNABORTED') {
      errorMessage = 'Koneksi ke server terputus (timeout). Silakan coba lagi nanti.';
    }
    m.reply(`> ☘️ *Gagal mencari gambar di Pinterest!*\nError: ${errorMessage}`);
  }
};

handler.command = ['pinterest', 'pin'];
handler.help = ['pinterest <query>', 'pin <query>'];
handler.tags = ['search'];
handler.limit = 3; // Menambahkan limit untuk penggunaan

module.exports = handler;
