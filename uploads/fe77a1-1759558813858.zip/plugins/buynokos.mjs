import fetch from "node-fetch"

// API KEY VirtuSim
const apikeyVirtuSim = "NHr2pEaOv1Gzs57nWFc3RjXCefZmTu"

let handler = async (m, { conn, text, usedPrefix }) => {
  const reply = (txt) => m.reply(txt)

  if (!text) return reply(
    `❌ Format salah!\n\nContoh:\n${usedPrefix}buynokos whatsapp|Indonesia`
  )

  let [service, country] = text.split("|")
  if (!service || !country) return reply(
    `❌ Format salah!\n\nContoh:\n${usedPrefix}buynokos whatsapp|Indonesia`
  )

  service = service.trim().toLowerCase()
  country = country.trim()

  try {
    // Ambil daftar service untuk negara
    let cekhar = await fetchJson(
      `https://virtusim.com/api/json.php?api_key=${apikeyVirtuSim}&action=services&country=${encodeURIComponent(country)}`
    )
    if (!cekhar || !cekhar.data)
      return reply(`❌ Tidak ada data service untuk negara *${country}*`)

    // Cari service ID
    let found = cekhar.data.find(x => x.name.toLowerCase().includes(service))
    if (!found) return reply(`❌ Service *${service}* tidak ditemukan di negara *${country}*`)

    let serviceId = found.id
    let pricee = found.rate || found.price || "0"

    // Order nomor
    let order = await fetchJson(
      `https://virtusim.com/api/json.php?api_key=${apikeyVirtuSim}&action=order&service=${serviceId}&operator=any`
    )

    if (!order || order.status !== true)
      return reply(`❌ Gagal order nomor: ${order?.data?.msg || "Unknown error"}`)

    let d = order.data
    let teks = `───「  *CREATE NUMBER*  」────

*ID:* ${d.id}
*NUMBER:* ${d.number}
*OPERATOR:* ${d.operator}
*SERVICE ID:* ${d.service_id}
*SERVICE NAME:* ${d.service_name}
*HARGA:* Rp ${pricee}

> Untuk mengirim SMS: *${usedPrefix}sendsms ${d.id}* 
> Untuk mengecek SMS: *${usedPrefix}getstatus ${d.id}*
> Jika SMS belum masuk: *${usedPrefix}resend ${d.id}*
> Batalkan order: *${usedPrefix}cansel ${d.id}*
`

    await conn.sendMessage(m.chat, { text: teks }, { quoted: m })

    // Notifikasi ke owner
    await conn.sendMessage("6285600793871@s.whatsapp.net", {
      text: `───「  *ORDERAN BARU*  」────
      
*ID:* ${d.id}
*NUMBER:* ${d.number}
*OPERATOR:* ${d.operator}
*SERVICE ID:* ${d.service_id}
*SERVICE NAME:* ${d.service_name}
*HARGA:* Rp ${pricee}`
    }, { quoted: m })

  } catch (e) {
    console.error(e)
    reply(`❌ Error: ${e.message}`)
  }
}

handler.command = /^buynokos$/i
handler.owner = true

export default handler

// Helper fetchJson
async function fetchJson(url, options) {
  let res = await fetch(url, options)
  if (!res.ok) throw new Error(`HTTP ${res.status} ${res.statusText}`)
  return res.json()
}
