import fetch from "node-fetch"
import axios from "axios"

// API KEY VirtuSim
const apikeyVirtuSim = "NHr2pEaOv1Gzs57nWFc3RjXCefZmTu"

const handler = async (m, { conn, command, text, usedPrefix }) => {
  const reply = (txt) => m.reply(txt)
  const q = text?.trim()

  try {
    switch (command) {
      case "getstatus": {
        if (!q) return reply(`> Masukkan ID pesanan\n> Contoh: ${usedPrefix}getstatus 12345`)

        let res = await axios.get(
          `https://virtusim.com/api/json.php?api_key=${apikeyVirtuSim}&action=status&id=${q}`
        )

        if (res.data.status === false)
          return reply(`❌ ${res.data.data?.msg || "ID tidak ditemukan"}`)

        let d = res.data.data
        return reply(
          `───「  *STATUS*  」────
*ID:* ${d.id}
*NUMBER:* ${d.number}
*STATUS:* ${d.status}
*SMS:* ${d.sms}
*SERVICE NAME:* ${d.service_name}

> Jika sudah 5 menit OTP belum masuk, batalkan dengan *${usedPrefix}cansel ${d.id}*`
        )
      }

      case "cansel": {
        if (!q) return reply(`> Masukkan ID pesanan\n> Contoh: ${usedPrefix}cansel 12345`)

        let res = await axios.get(
          `https://virtusim.com/api/json.php?api_key=${apikeyVirtuSim}&action=set_status&id=${q}&status=2`
        )

        let d = res.data.data
        return reply(
          `───「  *CANSEL STATUS*  」────
*PESAN:* ${res.data.msg}
*ID:* ${d?.id || "-"}
*SERVICE NAME:* ${d?.service_name || "-"}
          
> Mohon kembalikan saldo user dengan *${usedPrefix}addsaldo*`
        )
      }

      case "sendsms": {
        if (!q) return reply(`> Masukkan ID pesanan\n> Contoh: ${usedPrefix}sendsms 12345`)

        let res = await axios.get(
          `https://virtusim.com/api/json.php?api_key=${apikeyVirtuSim}&action=set_status&id=${q}&status=1`
        )

        let d = res.data.data
        return reply(
          `───「  *SMS STATUS*  」────
*PESAN:* ${res.data.msg}
*ID:* ${d?.id || "-"}
*SERVICE NAME:* ${d?.service_name || "-"}

> Gunakan *${usedPrefix}getstatus ${d?.id}* untuk cek SMS`
        )
      }

      case "resend": {
        if (!q) return reply(`> Masukkan ID pesanan\n> Contoh: ${usedPrefix}resend 12345`)

        let res = await axios.get(
          `https://virtusim.com/api/json.php?api_key=${apikeyVirtuSim}&action=set_status&id=${q}&status=3`
        )

        let d = res.data.data
        return reply(
          `───「  *RESEND STATUS*  」────
*PESAN:* ${res.data.msg}
*ID:* ${d?.id || "-"}
*SERVICE NAME:* ${d?.service_name || "-"}

> Gunakan *${usedPrefix}getstatus ${d?.id}* untuk cek ulang SMS`
        )
      }

      case "getservice": {
        if (!q) return reply(
          `> Masukkan nama negara\n> Contoh: ${usedPrefix}getservice indonesia\n\n` +
          `Untuk melihat daftar negara: *${usedPrefix}negara*`
        )

        let config = await fetchJson(
          `https://virtusim.com/api/json.php?api_key=${apikeyVirtuSim}&action=services&country=${encodeURIComponent(q)}`
        )

        if (!config?.data) return reply("❌ Tidak ada data layanan ditemukan")

        let teks = `───「  *LIST SERVICE ${q.toUpperCase()}*  」────\n\n`
        for (let r of config.data) {
          teks += `*• ID:* ${r.id}\n*• APK:* ${r.name}\n*• Harga:* Rp ${r.price}\n*• Tersedia:* ${r.tersedia}\n\n`
        }

        return reply(teks)
      }
    }
  } catch (e) {
    console.error(e)
    reply(`❌ Error: ${e.message}`)
  }
}

handler.command = /^(getstatus|cansel|sendsms|resend|getservice)$/i
handler.owner = true

export default handler

// Helper fetchJson
async function fetchJson(url, options) {
  let res = await fetch(url, options)
  if (!res.ok) throw new Error(`HTTP ${res.status} ${res.statusText}`)
  return res.json()
}
