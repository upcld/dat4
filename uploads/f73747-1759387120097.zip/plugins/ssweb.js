// > Creator: Danz
// > Plugin: ssweb.js
// > Fungsi: Mengambil screenshot website berdasarkan URL yang diberikan
// > Akses: Semua pengguna
// > Format: .ssweb <url>

const axios = require('axios');

async function ssweb(url, { width = 1280, height = 720, full_page = false, device_scale = 1 } = {}) {
  try {
    if (!url.startsWith('http')) throw new Error('URL tidak valid! Pastikan dimulai dengan http atau https.');
    if (isNaN(width) || isNaN(height) || isNaN(device_scale)) throw new Error('Lebar, tinggi, dan skala harus berupa angka!');
    if (typeof full_page !== 'boolean') throw new Error('Opsi full page harus berupa boolean!');

    const { data } = await axios.post(
      'https://gcp.imagy.app/screenshot/createscreenshot',
      {
        url: url,
        browserWidth: parseInt(width),
        browserHeight: parseInt(height),
        fullPage: full_page,
        deviceScaleFactor: parseInt(device_scale),
        format: 'png',
      },
      {
        headers: {
          'content-type': 'application/json',
          referer: 'https://imagy.app/full-page-screenshot-taker/',
          'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36',
        },
      }
    );

    return data.fileUrl;
  } catch (error) {
    throw new Error(error.message);
  }
}

let handler = async (m, { conn, args }) => {
  if (!args[0]) return m.reply('> ☘️ *Masukkan URL website!*\nContoh: *.ssweb https://example.com*');

  m.reply('> ☘️ *Sedang memproses screenshot...*');

  try {
    const img = await ssweb(args[0]);
    await conn.sendMessage(m.chat, { image: { url: img }, caption: `> ☘️ *Screenshot berhasil diambil!*` }, { quoted: m });
  } catch (e) {
    console.error(e);
    m.reply(`> ☘️ *Gagal mengambil screenshot!*\nError: ${e.message}`);
  }
};

handler.command = ['ssweb', 'screenshot', 'ss'];
handler.help = ['ssweb <url>'];
handler.tags = ['tools'];
handler.limit = true; // Menambahkan limit untuk penggunaan

module.exports = handler;
