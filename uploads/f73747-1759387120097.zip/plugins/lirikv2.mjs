// plugin/lyrics.js (ESM)
import fs from 'fs'
import path from 'path'
import axios from 'axios'
import { createCanvas, registerFont } from 'canvas'

// Load font custom kalau ada di ./fonts
try {
  const fontsDir = path.resolve('./fonts')
  if (fs.existsSync(path.join(fontsDir, 'Poppins-Bold.ttf'))) {
    registerFont(path.join(fontsDir, 'Poppins-Bold.ttf'), { family: 'Poppins', weight: '700' })
  }
  if (fs.existsSync(path.join(fontsDir, 'Poppins-Regular.ttf'))) {
    registerFont(path.join(fontsDir, 'Poppins-Regular.ttf'), { family: 'Poppins', weight: '400' })
  }
} catch (err) {
  console.warn('Font load warning:', err.message)
}

function wrapText(ctx, text, maxWidth) {
  const words = text.split(/\s+/)
  const lines = []
  let line = ''
  for (let n = 0; n < words.length; n++) {
    const testLine = line ? (line + ' ' + words[n]) : words[n]
    const metrics = ctx.measureText(testLine)
    if (metrics.width > maxWidth && line) {
      lines.push(line)
      line = words[n]
    } else {
      line = testLine
    }
  }
  if (line) lines.push(line)
  return lines
}

async function fetchLyrics(query) {
  const apiKey = global.hookrestKey || global.apikey
  if (!apiKey) throw new Error('API key hookrest belum diatur di config.')

  const url = `https://hookrest.my.id/search/lirikv2?title=${encodeURIComponent(query)}&apikey=${apiKey}`
  const res = await axios.get(url, { timeout: 15000 })
  return res.data
}

export default {
  help: ['lirik2 <judul>'],
  tags: ['tools'],
  command: ['lirik2'],
  limit: true,

  code: async (m, { conn, args }) => {
    if (!args || args.length === 0) {
      return m.reply('Kirim perintah diikuti judul lagu, contoh:\n.lirikv2 tabola bale')
    }

    const query = args.join(' ').trim()
    try {
      m.reply(`*_proses kaka @${m.sender.split('@')[0]}..._*`, m.chat, { mentions: [m.sender] })

      const data = await fetchLyrics(query)

      if (!data || data.status !== true || !data.result || data.result.length === 0) {
        return m.reply('Maaf, lirik tidak ditemukan untuk judul tersebut.')
      }

      const { name, artistName, plainLyrics } = data.result[0]

      // Canvas setup
      const canvasWidth = 1200
      const padding = 80
      const lineHeight = 42
      const lyricsFont = `400 ${lineHeight}px Poppins, Sans`

      const measureCanvas = createCanvas(canvasWidth, 2000)
      const mctx = measureCanvas.getContext('2d')
      mctx.font = lyricsFont

      const lyricLines = []
      const paragraphs = plainLyrics.split(/\n{1,}/g)
      for (const p of paragraphs) {
        if (!p.trim()) {
          lyricLines.push('')
          continue
        }
        lyricLines.push(...wrapText(mctx, p, canvasWidth - padding * 2))
        lyricLines.push('')
      }

      const canvasHeight = padding * 2 + lyricLines.length * lineHeight + 200
      const canvas = createCanvas(canvasWidth, Math.max(canvasHeight, 600))
      const ctx = canvas.getContext('2d')

      // Background gradient modern
      const grad = ctx.createLinearGradient(0, 0, canvas.width, canvas.height)
      grad.addColorStop(0, '#1e3c72') // biru gelap
      grad.addColorStop(1, '#2a5298') // biru terang
      ctx.fillStyle = grad
      ctx.fillRect(0, 0, canvas.width, canvas.height)

      // Semi-transparent card untuk teks
      ctx.fillStyle = 'rgba(0,0,0,0.35)'
      ctx.fillRect(padding / 2, padding / 2, canvas.width - padding, canvas.height - padding)

      // Judul
      ctx.font = 'bold 50px Poppins, Sans'
      ctx.fillStyle = '#ffffff'
      ctx.fillText(name, padding, padding + 20)

      // Artis
      ctx.font = '28px Poppins, Sans'
      ctx.fillStyle = '#a5b4fc' // soft indigo
      ctx.fillText(artistName, padding, padding + 70)

      // Lirik
      ctx.font = lyricsFont
      ctx.fillStyle = 'rgba(255,255,255,0.95)'
      let y = padding + 140
      for (const line of lyricLines) {
        if (line === '') {
          y += lineHeight / 1.5
          continue
        }
        ctx.fillText(line, padding, y)
        y += lineHeight
      }

      // Watermark
      const wm = 'hookrest.my.id • lyrics'
      ctx.font = 'italic 14px Poppins, Sans'
      ctx.fillStyle = 'rgba(255,255,255,0.4)'
      ctx.textAlign = 'right'
      ctx.fillText(wm, canvas.width - padding, canvas.height - 30)

      const buffer = canvas.toBuffer('image/png')

      await conn.sendMessage(
        m.chat,
        { image: buffer, caption: `${name} — ${artistName}` },
        { quoted: m }
      )
    } catch (err) {
      console.error(err)
      m.reply('Terjadi kesalahan saat mengambil/merender lirik: ' + (err.message || err))
    }
  }
}
