// plugin/kata.js (ESM)
import fs from 'fs'
import path from 'path'

export default {
  help: ['kata', 'quotes'],
  tags: ['quotes'],
  command: ['kata', 'quotes'],
  limit: false,

  code: async (m, { conn }) => {
    try {
      const filePath = path.resolve('./database/data.json')
      const raw = fs.readFileSync(filePath, 'utf-8')
      const json = JSON.parse(raw)

      if (!json.quotes || !Array.isArray(json.quotes) || json.quotes.length === 0) {
        return m.reply('Data quotes kosong atau tidak ditemukan.')
      }

      const randomQuote = json.quotes[Math.floor(Math.random() * json.quotes.length)]

      let text = randomQuote.text
      if (randomQuote.translation) {
        text += `\n\n> *Terjemahan:* ${randomQuote.translation}`
      }

      await conn.sendMessage(
        m.chat,
        { text },
        { quoted: m }
      )
    } catch (err) {
      console.error('Error plugin kata:', err)
      m.reply('Terjadi kesalahan saat mengambil quotes.')
    }
  }
}
