const fetch = require('node-fetch');

let wallpaperHD = async (m, { conn, args, usedPrefix, command }) => {
    if (!args[0]) return m.reply(`> *Contoh:* ${usedPrefix + command} Anime`);

    const query = args.join(" ");
    const apiUrl = `https://hookrest.my.id/tools/walpaperhd?query=${encodeURIComponent(query)}`;

    try {
        const res = await fetch(apiUrl);
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const json = await res.json();

        if (!json.status || !json.results || json.results.length === 0) {
            throw new Error("Tidak ada hasil wallpaper ditemukan");
        }

        // Pilih 1 data random
        const selected = json.results[Math.floor(Math.random() * json.results.length)];

        // Buat caption
        let caption = `> *Judul:* ${selected.title || '-'}\n> *Resolusi:* ${selected.resolution || '-'}\n> *Link:* ${selected.link || '-'}`;

        // Kirim gambar
        await conn.sendMessage(m.chat, {
            image: { url: selected.imageUrl },
            caption
        }, { quoted: m });

    } catch (err) {
        console.error(err);
        m.reply('> Terjadi kesalahan saat mengambil wallpaper.');
    }
};

wallpaperHD.command = ['uhdpapper', 'walpaperhd'];
wallpaperHD.help = ['uhdpapper <query>', 'walpaperhd <query>'];
wallpaperHD.tags = ['tools'];
wallpaperHD.limit = true;
wallpaperHD.loading = true;

module.exports = wallpaperHD;
