/**
 * Text to Image Generator
 * Author : Danz-dev
 * API    : https://hookrest.my.id/tools/text2img
 */

const axios = require("axios")

let handler = async (m, { conn, text }) => {
  if (!text) return m.reply("*⚠️ Masukkan prompt untuk gambar!*\n\nContoh:\n.text2img Gunung Everest")

  try {
    await m.reply("_> Proses generate gambar..._")

    const apiUrl = `https://hookrest.my.id/tools/text2img?prompt=${encodeURIComponent(text)}&apikey=hookrest`
    const response = await axios.get(apiUrl, { responseType: "arraybuffer" })

    if (!response.data) throw new Error("Tidak ada gambar yang diterima dari API")

    await conn.sendFile(m.chat, response.data, "hasil.jpg", `*Hasil generate dari prompt:*\n${text}`, m)

  } catch (err) {
    console.error("❌ Error text2img:", err)
    m.reply("*❌ Gagal generate gambar:*\n" + err.message)
  }
}

handler.help = ["text2img <prompt>"]
handler.tags = ["ai", "tools"]
handler.command = /^text2img$/i

module.exports = handler
