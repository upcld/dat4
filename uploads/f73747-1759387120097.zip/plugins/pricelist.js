// > Creator: Danz
// > Plugin: topup.js
// > Deskripsi: Fitur topup, pricelist, validasi token, QRIS & saldo

const fs = require("fs");
const crypto = require("crypto");
const fetch = require("node-fetch");

function toRupiah(angka) {
  angka = Number(angka) || 0;
  return "Rp" + angka.toLocaleString("id-ID");
}

// Simulasi saldo user
if (!global.saldoUser) global.saldoUser = {};
async function cekSaldo(m) { return global.saldoUser[m.sender] || 0; }
async function kurangSaldo(m, jumlah) {
  global.saldoUser[m.sender] = (global.saldoUser[m.sender] || 0) - jumlah;
  return global.saldoUser[m.sender];
}

const transactionsPath = "./transactions.json";
if (!fs.existsSync(transactionsPath)) fs.writeFileSync(transactionsPath, JSON.stringify([]));
async function getTransactions() { return JSON.parse(fs.readFileSync(transactionsPath)); }
async function saveTransactions(data) { fs.writeFileSync(transactionsPath, JSON.stringify(data, null, 2)); }

let handler = async (m, { conn, text, command, usedPrefix }) => {
  try {
    switch (command) {

      case 'pricelist': {
        if (!global.config?.atlanticKey) return m.reply("> API key Atlantic belum diatur di config.");

        const key = new URLSearchParams();
        key.append("api_key", global.config.atlanticKey);
        key.append("type", "prabayar");

        const rest = await fetch("https://atlantich2h.com/layanan/price_list", {
          method: "POST",
          body: key
        });
        const res = await rest.json();
        if (!res.status) return m.reply("> Gagal mengambil data pricelist.");

        const keyword = text ? text.toLowerCase() : null;
        let grouped = {};

        for (let item of res.data) {
          let category = (item.category || "Lainnya").trim();
          if (keyword &&
              !((category || "").toLowerCase().includes(keyword)) &&
              !((item.provider || "").toLowerCase().includes(keyword)) &&
              !((item.product_name || "").toLowerCase().includes(keyword))) continue;
          if (!grouped[category]) grouped[category] = [];
          grouped[category].push(item);
        }

        if (Object.keys(grouped).length === 0) return m.reply(`> Tidak ada layanan untuk kata kunci *${text}*`);

        let output = `> Daftar Pricelist ${keyword ? `untuk *${text}*` : ""}\n\n`;
        for (let [category, items] of Object.entries(grouped)) {
          output += `> Kategori: *${category.toUpperCase()}*\n`;
          for (let item of items) { // tampilkan semua produk
            output += `- ${item.product_name || item.name} ${toRupiah(item.price)} *${item.product_code || item.code}*\n`;
          }
          output += "\n";
        }
        return conn.reply(m.chat, output.trim(), m);
      }

      case 'topup': {
        if (!text) return m.reply(`> Gunakan: ${usedPrefix}topup <product_code>|<target>|<metode>\n> Metode: qris / saldo`);

        let [product, target, metode] = text.split("|");
        if (!product || !target || !metode) return m.reply("> Format salah. Contoh: topup ML5|628xxxx|saldo");

        metode = (metode || "").toLowerCase();
        if (!["qris", "saldo"].includes(metode)) return m.reply("> Metode harus qris / saldo");
        if (!global.config?.atlanticKey) return m.reply("> API key Atlantic belum diatur di config.");

        // Ambil pricelist
        const key = new URLSearchParams();
        key.append("api_key", global.config.atlanticKey);
        key.append("type", "prabayar");
        const rest = await fetch("https://atlantich2h.com/layanan/price_list", {
          method: "POST",
          body: key
        });
        const res = await rest.json();
        if (!res.status) return m.reply("> Gagal ambil data produk.");

        const found = res.data.find(i => ((i.product_code || i.code || "").toLowerCase()) === product.toLowerCase());
        if (!found) return m.reply("> Produk tidak ditemukan.");

        const margin = global.config.marginUntung || 500;
        const harga = parseInt(found.price) + margin;
        const saldo = await cekSaldo(m);

        let token = crypto.randomBytes(4).toString("hex").toUpperCase();
        let transaksi = {
          id: crypto.randomBytes(6).toString("hex"),
          user: m.sender,
          product: found.product_name || found.name,
          provider: found.provider,
          target,
          metode,
          harga,
          token,
          status: "PENDING",
          date: new Date().toISOString(),
        };

        let all = await getTransactions();
        all.push(transaksi);
        await saveTransactions(all);

        if (metode === "saldo") {
          if (saldo < harga) return m.reply(`> Saldo tidak cukup.\nHarga: ${toRupiah(harga)}\nSaldo: ${toRupiah(saldo)}`);
          await kurangSaldo(m, harga);
          transaksi.status = "SUCCESS";
          await saveTransactions(all);
          return conn.reply(m.chat, `> Transaksi berhasil diproses dengan saldo.\nProduk: ${transaksi.product}\nTarget: ${target}\nHarga: ${toRupiah(harga)}`, m);
        }

        // QRIS
        const params = new URLSearchParams();
        params.append("api_key", global.config.atlanticKey);
        params.append("reff_id", crypto.randomBytes(4).toString("hex"));
        params.append("nominal", harga);
        params.append("type", "ewallet");
        params.append("metode", "qrisfast");

        const qrisRes = await fetch("https://atlantich2h.com/deposit/create", {
          method: "POST",
          body: params
        });
        const qrisData = await qrisRes.json();
        if (!qrisData.status || !qrisData.data) return m.reply("> Gagal membuat transaksi QRIS.");

        const qrImageUrl = `https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(qrisData.data.qr_string)}`;
        return conn.sendMessage(m.chat, {
          image: { url: qrImageUrl },
          caption: `> TRANSAKSI QRIS PENDING\n\n• Produk: ${transaksi.product}\n• Target: ${target}\n• Harga: ${toRupiah(harga)}\n• Token: ${token}\n\nSilakan scan QRIS berikut untuk membayar.\nQR akan expired pada ${qrisData.data.expired_at}`
        });
      }

      case 'validasitoken': {
        if (!text) return m.reply(`> Gunakan: ${usedPrefix}validasitoken <token>`);
        let token = text.trim();
        let trx = (await getTransactions()).find(t => t.token === token);
        if (!trx) return m.reply("> Token tidak ditemukan.");
        if (trx.status !== "PENDING") return m.reply("> Token sudah dipakai atau tidak valid.");
        trx.status = "VALIDATED";

        let all = await getTransactions();
        let idx = all.findIndex(t => t.token === token);
        all[idx] = trx;
        await saveTransactions(all);

        return conn.reply(m.chat, `> Token *${token}* berhasil divalidasi untuk transaksi *${trx.product}*`, m);
      }

      case 'processorder': {
        if (!text) return m.reply(`> Gunakan: ${usedPrefix}processorder <token>|<target>`);
        let [token, target] = text.split("|");
        if (!token || !target) return m.reply("> Format salah.");

        let trx = (await getTransactions()).find(t => t.token === token);
        if (!trx) return m.reply("> Transaksi tidak ditemukan.");
        if (trx.target !== target) return m.reply("> Target tidak sesuai.");
        if (trx.status !== "VALIDATED") return m.reply("> Token belum divalidasi.");

        trx.status = "SUCCESS";
        let all = await getTransactions();
        let idx = all.findIndex(t => t.token === token);
        all[idx] = trx;
        await saveTransactions(all);

        return conn.reply(m.chat, `> Transaksi berhasil.\nProduk: ${trx.product}\nTarget: ${trx.target}\nHarga: ${toRupiah(trx.harga)}`, m);
      }

    }
  } catch (e) {
    console.error(e);
    m.reply("> Terjadi kesalahan: " + e.message);
  }
};

handler.help = ['pricelist [keyword]', 'topup <kode>|<target>|<metode>', 'validasitoken <token>', 'processorder <token>|<target>'];
handler.tags = ['store'];
handler.command = /^(pricelist|topup|validasitoken|processorder)$/i;

module.exports = handler;
