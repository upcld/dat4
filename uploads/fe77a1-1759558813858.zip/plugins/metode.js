const axios = require("axios")
const qs = require("qs")

async function getMetode({ type = "ewallet", method = "qris" }) {
  try {
    const data = qs.stringify({
      api_key: "BF3ovliJ3hNZ0U7kksctsmvvEvjFNFIlVDN606M3N9AYjgil2XouWYwaxOPRZ6mxsrHf5uoOqJufSMRPTuEhLXIJMtCGtUDEuVqx",
      type,
      method,
    })

    const config = {
      method: "post",
      maxBodyLength: Infinity,
      url: "https://atlantich2h.com/deposit/metode",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      data,
    }

    const { data: res } = await axios(config)
    return res
  } catch (err) {
    return { status: false, message: err.message }
  }
}

module.exports = {
  help: ["metode", "metodebayar<type> <method>"],
  tags: ["store"],
  command: ["metode", "metodebayar"],

  code: async (m, { conn, args }) => {
    const type = args[0] || "ewallet"
    const method = args[1] || "qris"

    m.reply(`🍃 Mengecek metode deposit...\nType: ${type}\nMethod: ${method}`)

    const result = await getMetode({ type, method })

    if (!result || !result.status) 
      return m.reply("🍃 Gagal mengambil metode: " + (result.message || "unknown error"))

    for (const item of result.data) {
      const teks = `*${item.name}*\n` +
                   `Type: ${item.type}\n` +
                   `Min: Rp ${item.min}\n` +
                   `Max: Rp ${item.max}\n` +
                   `Fee: Rp ${item.fee} + ${item.fee_persen}%\n` +
                   `Status: ${item.status}`

      await conn.sendMessage(m.chat, {
        image: { url: item.img_url },
        caption: teks
      }, { quoted: m })
    }
  },
}
