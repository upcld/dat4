const Jimp = require('jimp');

module.exports = {
    help: ['topixel <ukuran>'],
    tags: ['tools'],
    command: ['topixel'],
    limit: true,
    energy: 5,

    code: async (m, { conn, args }) => {
        const q = m.quoted ? m.quoted : m;
        const mime = (q.msg || q).mimetype || '';
        if (!mime.startsWith('image/')) return m.reply('> Mana gambarnya');

        let pixelSize = parseInt(args[0]) || 32;
        if (pixelSize < 8) pixelSize = 8;
        if (pixelSize > 1024) pixelSize = 1024;

        m.reply('🍃 Sedang memproses gambar...');

        try {
            const media = await q.download();
            const image = await Jimp.read(media);
            const small = image.clone().resize(pixelSize, pixelSize, Jimp.RESIZE_NEAREST_NEIGHBOR);
            const pixelated = small.resize(image.bitmap.width, image.bitmap.height, Jimp.RESIZE_NEAREST_NEIGHBOR);
            const buffer = await pixelated.getBufferAsync(Jimp.MIME_JPEG);

            await conn.sendMessage(m.chat, {
                image: buffer,
                caption: `🍃 Pixelated image (size: ${pixelSize})`
            }, { quoted: m });
        } catch (err) {
            m.reply(`> Terjadi kesalahan: ${err.message}`);
        }
    }
};
