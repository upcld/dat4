const fetch = require('node-fetch');
const cheerio = require('cheerio');
const fs = require('fs');
const path = require('path');

const API_URL = 'https://ttsave.app/download';
const OUTPUT_DIR = path.join(__dirname, 'downloads');

// Ensure the downloads directory exists
if (!fs.existsSync(OUTPUT_DIR)) {
    fs.mkdirSync(OUTPUT_DIR, { recursive: true });
}

// Obfuscate filename (replicating obfn function)
function obfuscateFilename(name) {
    if (!name || typeof name !== 'string') {
        console.warn('Invalid filename provided to obfuscateFilename, using default');
        name = `${Date.now()}-unknown.mp4`;
    }

    const parts = name.split('.');
    const extension = parts.length > 1 ? parts.pop() : 'mp4';
    const filename = parts.join('.');
    const segments = filename.split('-');
    const number = segments.shift() || Date.now().toString();
    const suffix = segments.join('-');

    const shuffle = (str) => str.split('').sort(() => Math.random() - 0.5).join('');
    const map = {
        'no-watermark': 'a',
        'watermark': 'b',
        'audio': 'c',
        'slide': 'd',
        'profile': 'e',
        'cover': 'f',
    };

    const shuffledNumber = shuffle(number);
    const newSuffix = map[suffix] || suffix || 'unknown';
    return newSuffix ? `${shuffledNumber}-${newSuffix}.${extension}` : `${shuffledNumber}.${extension}`;
}

// Base64 encode and reverse (replicating tb function)
function transformUrl(url) {
    if (!url || typeof url !== 'string') {
        console.warn('Invalid URL provided to transformUrl, returning empty string');
        return '';
    }
    return Buffer.from(url).toString('base64').split('').reverse().join('').replace(/\//g, '@');
}

// Generate download URL (replicating gdl function)
function generateDownloadUrl(url, name) {
    if (!url || !name) {
        console.warn('Invalid URL or name for generateDownloadUrl, returning original URL');
        return url || '';
    }
    return `https://ttsave.app/cdn/${transformUrl(url)}/${obfuscateFilename(name)}`;
}

// Determine file extension
function getExtension(type, url) {
    if (!url || typeof url !== 'string') return '.mp4';
    if (url.includes('.jpg')) return '.jpg';
    if (url.includes('.jpeg')) return '.jpeg';
    if (url.includes('.png')) return '.png';
    if (url.includes('.webp')) return '.webp';
    if (type === 'Watermark' || type === 'No Watermark') return '.mp4';
    if (type === 'Audio') return '.mp3';
    return '.mp4'; // Default
}

// Download file with retry logic
async function downloadFile(url, name, retry = 0, maxRetries = 3) {
    if (!url || !name) {
        throw new Error('Invalid URL or name provided for download');
    }

    const obfuscatedName = obfuscateFilename(name);
    const filePath = path.join(OUTPUT_DIR, obfuscatedName);

    console.log(`Starting download: ${obfuscatedName}`);

    try {
        const response = await fetch(url, {
            method: 'GET',
            headers: {
                'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36',
            },
        });

        if (!response.ok) {
            throw new Error(`HTTP error ${response.status}`);
        }

        const writer = fs.createWriteStream(filePath);
        response.body.pipe(writer);

        return new Promise((resolve, reject) => {
            writer.on('finish', () => {
                console.log(`Downloaded: ${filePath}`);
                resolve(filePath);
            });
            writer.on('error', (err) => {
                console.error(`Error downloading ${obfuscatedName}:`, err.message);
                fs.unlink(filePath, () => {}); // Clean up partial file
                reject(err);
            });
        });
    } catch (error) {
        console.error(`Download failed for ${obfuscatedName}:`, error.message);
        if (retry < maxRetries) {
            console.log(`Retrying download (${retry + 1}/${maxRetries})...`);
            return downloadFile(url, name, retry + 1, maxRetries);
        } else {
            console.log(`Falling back to alternative URL for ${obfuscatedName}`);
            const fallbackUrl = generateDownloadUrl(url, name);
            return downloadFile(fallbackUrl, name, 0, maxRetries);
        }
    }
}

// Fetch HTML from ttsave.app API
async function fetchTtSaveHtml(query) {
    if (!query || typeof query !== 'string') {
        throw new Error('Please provide a valid TikTok URL or username');
    }

    const body = { query, language_id: '1' };
    const headers = {
        'Content-Type': 'application/json',
        'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36',
    };

    const res = await fetch(API_URL, {
        method: 'POST',
        headers,
        body: JSON.stringify(body),
    });

    if (!res.ok) {
        throw new Error(`Gagal menghubungi API TikTok: HTTP ${res.status}`);
    }

    const data = await res.text();
    console.log('API response received:', data); // Log for debugging
    return data;
}

// Extract download links from HTML
function extractDownloadLinks(html) {
    const $ = cheerio.load(html);
    const links = [];

    // Parse <a> tags for videos and audio
    $('a').each((i, el) => {
        const href = $(el).attr('href');
        const text = $(el).text().toLowerCase();
        const dataType = $(el).attr('data-type');
        if (!href || !href.startsWith('http')) return;

        let type;
        if (dataType) {
            type = dataType.includes('no-watermark') ? 'No Watermark' :
                   dataType.includes('watermark') ? 'Watermark' :
                   dataType.includes('audio') ? 'Audio' :
                   dataType.includes('slide') ? 'Slide' :
                   dataType.includes('profile') ? 'Profile' :
                   dataType.includes('thumbnail') ? 'Thumbnail' : 'Unknown';
        } else if (text.includes('no watermark')) {
            type = 'No Watermark';
        } else if (text.includes('watermark')) {
            type = 'Watermark';
        } else if (text.includes('audio')) {
            type = 'Audio';
        } else if (text.includes('slide')) {
            type = 'Slide';
        } else if (text.includes('profile')) {
            type = 'Profile';
        } else if (text.includes('thumbnail') || text.includes('cover')) {
            type = 'Thumbnail';
        } else {
            return; // Skip irrelevant links
        }

        links.push({ type, url: href });
    });

    // Parse <img> tags for slides, profiles, and thumbnails
    $('img').each((i, el) => {
        const src = $(el).attr('src');
        const alt = $(el).attr('alt')?.toLowerCase() || '';
        if (!src || !src.startsWith('http')) return;

        let type;
        if (alt.includes('slide')) {
            type = 'Slide';
        } else if (alt.includes('profile')) {
            type = 'Profile';
        } else if (alt.includes('thumbnail') || alt.includes('cover')) {
            type = 'Thumbnail';
        } else {
            return; // Skip irrelevant images
        }

        links.push({ type, url: src });
    });

    if (!links.length) {
        throw new Error('Tidak ditemukan link download video.');
    }

    return links;
}

// Main scraper function
const handler = async (url) => {
    if (!url || typeof url !== 'string') {
        throw new Error('Please provide a TikTok URL (e.g., https://vm.tiktok.com/ZS1A2B3C/)');
    }

    // Validate TikTok URL
    if (!url.match(/^(https?:\/\/)?(vm|vt|www|m)\.tiktok\.com\//)) {
        throw new Error('Harap masukkan URL TikTok yang valid (contoh: https://vm.tiktok.com/ZS1A2B3C/)');
    }

    try {
        // Fetch and parse HTML
        const html = await fetchTtSaveHtml(url);
        const links = extractDownloadLinks(html);

        const results = [];
        for (const { url: linkUrl, type } of links) {
            const filename = `${Date.now()}-${type.toLowerCase().replace(' ', '-')}${getExtension(type, linkUrl)}`;
            const filePath = await downloadFile(linkUrl, filename);
            results.push({ type, url: linkUrl, filePath });
        }

        return {
            status: true,
            url,
            results,
        };
    } catch (err) {
        console.error('Error in scraper:', err);
        throw new Error(`Terjadi kesalahan: ${err.message}`);
    }
};

// Module metadata
handler.help = ['tiktok <url>'];
handler.tags = ['downloader'];
handler.command = /^((ttsv|tiktok)(dl)?)$/i;

// Export the handler
module.exports = handler;

// Example usage for testing
(async () => {
    const testUrl = process.argv[2] || 'https://vm.tiktok.com/ZS1A2B3C/';
    try {
        const result = await handler(testUrl);
        console.log('Scraping completed:', result);
        result.results.forEach(({ type, filePath }) => {
            console.log(`- ${type}: ${filePath}`);
        });
    } catch (err) {
        console.error(err.message);
    }
})();