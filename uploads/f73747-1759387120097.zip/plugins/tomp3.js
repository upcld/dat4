// Plugin: tomp3.js
// Fungsi: Mengubah VN (audio/voice note) atau Video menjadi format MP3
// Dependensi: fluent-ffmpeg, fs, path

const fs = require("fs")
const path = require("path")
const { toOpus, generateWaveform } = require("../lib/audioConverter")
const ffmpeg = require("fluent-ffmpeg")

module.exports = {
  help: ["tomp3"],
  tags: ["tools"],
  command: ["tomp3", "toaudio"],
  limit: true,
  energy: 5,

  code: async (m, { conn }) => {
    const q = m.quoted ? m.quoted : m
    const mime = (q.msg || q).mimetype || ""

    if (!/video|audio/.test(mime)) return m.reply(`Kirim/reply video atau vn dengan perintah .tomp3`)

    m.reply("🍃 Tunggu sebentar, sedang mengonversi ke MP3...")

    try {
      const media = await q.download()

      if (mime.includes("audio")) {
        // For audio files, convert to opus with waveform
        const opusBuffer = await toOpus(media)
        const waveform = await generateWaveform(opusBuffer)

        await conn.sendMessage(
          m.chat,
          {
            audio: opusBuffer,
            waveform: waveform,
            mimetype: "audio/ogg; codecs=opus",
            ptt: false,
            fileName: `convert.ogg`,
          },
          { quoted: m },
        )
      } else {
        // For video files, use traditional ffmpeg conversion to MP3
        const inputPath = path.join(__dirname, `../tmp/${Date.now()}.input`)
        const outputPath = path.join(__dirname, `../tmp/${Date.now()}.mp3`)

        fs.writeFileSync(inputPath, media)

        await new Promise((resolve, reject) => {
          ffmpeg(inputPath).toFormat("mp3").on("end", resolve).on("error", reject).save(outputPath)
        })

        await conn.sendMessage(
          m.chat,
          {
            audio: fs.readFileSync(outputPath),
            mimetype: "audio/mpeg",
            ptt: false,
            fileName: `convert.mp3`,
          },
          { quoted: m },
        )

        fs.unlinkSync(inputPath)
        fs.unlinkSync(outputPath)
      }
    } catch (e) {
      console.error(e)
      m.reply("🍃 Terjadi kesalahan saat konversi.")
    }
  },
}
