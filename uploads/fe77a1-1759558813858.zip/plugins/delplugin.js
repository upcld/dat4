// > Creator: Danz
// > Plugin: delplugin.js
// > Fungsi: Menghapus file plugin dari folder ./plugins/ (mendukung .js dan .mjs)
// > Akses: Real Owner
// > Format: .delplugin namafile.js atau .delplugin namafile.mjs

const fs = require('fs');

let handler = async (m, { text }) => {
  if (!text) return m.reply('> ☘️ *Masukkan nama file plugin yang ingin dihapus!*\nContoh: *.delplugin namafile.js* atau *.delplugin namafile.mjs*');
  if (!text.match(/\.(js|mjs)$/)) return m.reply('> ☘️ *Nama file harus berformat .js atau .mjs*');

  const filePath = `./plugins/${text.toLowerCase()}`;
  if (!fs.existsSync(filePath)) {
    return m.reply('> ☘️ *File plugin tidak ditemukan!*');
  }

  try {
    fs.unlinkSync(filePath);
    return m.reply(`> ☘️ *Berhasil menghapus plugin*\nNama file: *${text.toLowerCase()}*`);
  } catch (e) {
    console.error(e);
    return m.reply('> ☘️ *Gagal menghapus file plugin!*');
  }
};

handler.command = ['delplugin', 'delplugins'];
handler.help = ['delplugin <namafile.js|namafile.mjs>'];
handler.tags = ['owner'];
handler.owner = true;

module.exports = handler;