let handler = async (m, { conn, participants, text }) => {
  if (!m.chat.endsWith('@g.us')) {
    return m.reply("❌ Fitur ini khusus untuk grup!")
  }

  let message = text ? text : "📢 Tag Semua Anggota Grup!"
  let users = participants.map(u => u.id)

  await conn.sendMessage(m.chat, {
    text: message,
    mentions: users
  }, { quoted: m })
}

handler.help = ['tagall <pesan>']
handler.tags = ['group']
handler.command = /^(tagall|all)$/i

handler.group = true
handler.admin = true

export default handler
