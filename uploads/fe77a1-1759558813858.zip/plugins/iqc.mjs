/*
* Nama fitur : iqc (Iphone Quoted)
* Type       : Plugin ESM
* Sumber     : https://whatsapp.com/channel/0029Vb6Zs8yEgGfRQWWWp639
* Author     : ZenzzXD (modifikasi untuk kompatibilitas bot oleh ChatGPT)
*/

import fetch from 'node-fetch'

let handler = async (m, { conn, text }) => {
  if (!text) {
    return m.reply(`> Gunakan: *.iqc jam|batre|pesan*
> Contoh: *.iqc 18:00|40|hai hai*`)
  }

  let [time, battery, ...msgParts] = text.split('|')
  if (!time || !battery || msgParts.length === 0) {
    return m.reply(`> Format salah!
Gunakan: *.iqc jam|batre|pesan*
Contoh: *.iqc 18:00|40|hai hai*`)
  }

  m.reply('> Sedang membuat gambar, tunggu sebentar...')

  let messageText = encodeURIComponent(msgParts.join('|').trim())
  let url = `https://brat.siputzx.my.id/iphone-quoted?time=${encodeURIComponent(time)}&batteryPercentage=${battery}&carrierName=INDOSAT&messageText=${messageText}&emojiStyle=apple`

  let res = await fetch(url)
  if (!res.ok) return m.reply('> Gagal mengambil data dari server.')

  let buffer = await res.buffer()
  await conn.sendMessage(m.chat, { image: buffer }, { quoted: m })
}

handler.help = ['iqc jam|batre|pesan']
handler.tags = ['maker']
handler.command = /^iqc$/i

export default handler
