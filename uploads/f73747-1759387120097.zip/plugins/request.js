const fetch = require('node-fetch');

let handler = async (m, { conn, text }) => {
  if (!text || !text.includes('|'))
    return m.reply('> Format salah!\n> Contoh:\n> .requestfitur namafitur|deskripsi fitur');

  try {
    const TELEGRAM_BOT_TOKEN = '7825035705:AAGxHALGfVXXek1kcqyRlt85tr92lG1uVNM';
    const TELEGRAM_CHAT_ID = '7638505301';

    const from = m.sender;
    const name = await conn.getName(from);
    const nomor = from.split('@')[0];

    const [fiturRaw, ...descParts] = text.split('|');
    const fitur = fiturRaw.trim();
    const deskripsi = descParts.join('|').trim();

    if (!fitur) return m.reply('> Tolong tulis nama fitur yang ingin direquest sebelum tanda |');
    if (!deskripsi) return m.reply('> Tolong tulis deskripsi fitur setelah tanda |');

    const pesan = `*𝐀𝐝𝐚 𝐫𝐞𝐪𝐮𝐞𝐬𝐭*\n` +
      `ᴅᴀʀɪ : *${name}*\n` +
      `ɴᴏᴍᴏʀ : *${nomor}*\n` +
      `ʀᴇǫᴜᴇsᴛ : *${fitur}*\n` +
      `ᴅᴇsᴋ : ${deskripsi}`;

    const thumbnailUrl = 'https://files.catbox.moe/z5pbpf.jpg'; // Ganti sesuai kebutuhan

    // Kirim request ke Telegram pakai sendPhoto
    const url = `https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendPhoto`;
    const resp = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        chat_id: TELEGRAM_CHAT_ID,
        photo: thumbnailUrl,
        caption: pesan,
        parse_mode: 'Markdown'
      })
    });

    const json = await resp.json();
    if (!json.ok) throw new Error(json.description || 'Failed to send message');

    m.reply('> Terima kasih, request fitur sudah dikirim ke admin.');

  } catch (e) {
    console.error('Error kirim request fitur:', e);
    m.reply('> Gagal mengirim request fitur, coba lagi nanti.');
  }
};

handler.help = ['requestfitur'];
handler.tags = ['main'];
handler.command = ['requestfitur', 'req'];

module.exports = handler;
