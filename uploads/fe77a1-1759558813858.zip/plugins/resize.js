const Jimp = require('jimp')

module.exports = {
  help: ['resize <width> <height>'],
  tags: ['tools'],
  command: ['resize'],
  limit: true,

  code: async (m, { conn, args }) => {
    const q = m.quoted ? m.quoted : m
    const mime = (q.msg || q).mimetype || ''

    if (!mime.startsWith('image/')) return m.reply('Kirim/quote gambar untuk diresize 🍃')

    let width = parseInt(args[0])
    let height = parseInt(args[1])

    if (!width || !height) {
      return m.reply('Masukkan ukuran yang valid, contoh:\n.toresize 512 512 🍃')
    }

    if (width < 16 || height < 16) return m.reply('Ukuran terlalu kecil minimal 16x16 🍃')
    if (width > 4096 || height > 4096) return m.reply('Ukuran terlalu besar maksimal 4096x4096 🍃')

    m.reply(`Sedang mengubah ukuran gambar ke ${width}x${height}... 🍃`)
    const media = await q.download()

    try {
      const image = await Jimp.read(media)
      image.resize(width, height, Jimp.RESIZE_BILINEAR)
      const buffer = await image.getBufferAsync(Jimp.MIME_JPEG)

      await conn.sendMessage(
        m.chat,
        { image: buffer, caption: `Gambar berhasil diresize ke ${width}x${height} 🍃` },
        { quoted: m }
      )
    } catch (e) {
      m.reply('Terjadi kesalahan: ' + e.message)
    }
  }
}
