let handler = async (m) => {
m.reply('ok')
}
handler.command = ['tes']

module.exports = handler
