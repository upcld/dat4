const { createCanvas, loadImage } = require('canvas');
const { Sticker } = require('wa-sticker-formatter');
const twemoji = require('twemoji');
const fetch = require('node-fetch');

let handler = async (m, { conn, text }) => {
    if (!text) return m.reply(`> Format salah!\n> Contoh: .brat Aku ganteng 😎`);

    try {
        const canvas = createCanvas(512, 512);
        const ctx = canvas.getContext('2d');

        // Background putih
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(0, 0, canvas.width, canvas.height);

        // Font setup
        let fontSize = 70; // lebih besar
        const maxWidth = canvas.width - 50; // margin kiri-kanan
        let lineHeight = 85; // jarak antar baris lebih jauh

        ctx.textAlign = 'left';
        ctx.textBaseline = 'top';
        ctx.fillStyle = '#000000';

        // Fungsi wrap text
        function wrapText(ctx, text, maxWidth) {
            const words = text.split(' ');
            const lines = [];
            let line = '';

            for (let i = 0; i < words.length; i++) {
                const testLine = line + words[i] + ' ';
                const metrics = ctx.measureText(testLine);
                if (metrics.width > maxWidth && i > 0) {
                    lines.push(line.trim());
                    line = words[i] + ' ';
                } else {
                    line = testLine;
                }
            }
            lines.push(line.trim());
            return lines;
        }

        // Sesuaikan font size biar muat
        let lines;
        do {
            ctx.font = `bold ${fontSize}px Arial`;
            lines = wrapText(ctx, text, maxWidth);
            if (lines.length * lineHeight > canvas.height - 40) { // jarak atas bawah lebih longgar
                fontSize -= 2;
                lineHeight -= 1;
            } else {
                break;
            }
        } while (fontSize > 20);

        // Render text + emoji
        let y = 30; // jarak dari atas lebih jauh
        for (let line of lines) {
            let x = 25; // margin kiri
            for (const char of [...line]) {
                if (twemoji.test(char)) {
                    const emojiUrl = twemoji.parse(char, {
                        folder: 'svg',
                        ext: '.svg'
                    }).match(/src="(.*?)"/)?.[1];

                    if (emojiUrl) {
                        const emojiPngUrl = emojiUrl.replace('/svg/', '/72x72/').replace('.svg', '.png');
                        const res = await fetch(emojiPngUrl);
                        const buf = await res.arrayBuffer();
                        const img = await loadImage(Buffer.from(buf));
                        ctx.drawImage(img, x, y, fontSize, fontSize);
                        x += fontSize;
                        continue;
                    }
                }
                ctx.fillText(char, x, y);
                x += ctx.measureText(char).width;
            }
            y += lineHeight;
        }

        // Convert jadi sticker
        const sticker = new Sticker(canvas.toBuffer(), {
            pack: 'Brat',
            author: 'Rin',
            type: 'full',
            quality: 100
        });

        await conn.sendMessage(m.chat, await sticker.toMessage(), { quoted: m });

    } catch (e) {
        console.error(e);
        m.reply('> Terjadi kesalahan saat membuat sticker.');
    }
};

handler.help = ['bratt <teks>'];
handler.tags = ['sticker'];
handler.command = /^bratt$/i;

module.exports = handler;
