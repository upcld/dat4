// > Creator: Danz
// > Plugin: enc.js

const JavaScriptObfuscator = require('javascript-obfuscator');

let handler = async (m, { conn, text }) => {
    if (!text) {
        return m.reply('> Masukan teks JavaScript yang ingin di-*encode*');
    }

    try {
        let res = JavaScriptObfuscator.obfuscate(text);
        await conn.reply(m.chat, res.getObfuscatedCode(), m);
    } catch (e) {
        await conn.reply(m.chat, `> Terjadi kesalahan\n> *Error:* ${e.message || e}`, m);
    }
};

handler.help = ['enc <kode>'];
handler.tags = ['tools'];
handler.command = /^enc$/i;

module.exports = handler;
