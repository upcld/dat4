const fetch = require("node-fetch")
const { toWhatsAppVoice } = require("../lib/audioConverter")

const handler = async (m, { conn, text, command }) => {
  if (!text) return m.reply(`> Contoh penggunaan:\n> .${command} https://vm.tiktok.com/ZSSts6HyN/`)

  try {
    await conn.sendMessage(m.chat, { react: { text: "⏳", key: m.key } })

    const apiUrl = `https://api-loop.vercel.app/download/tiktok?url=${encodeURIComponent(text)}`
    const res = await fetch(apiUrl)
    if (!res.ok) throw new Error("Gagal menghubungi API TikTok.")

    const json = await res.json()
    if (!json.status || !json.result || !json.result.play) {
      throw new Error("Gagal mengambil video dari API.")
    }

    const { title, author, duration, play, music_info } = json.result

    // Kirim video
    await conn.sendMessage(
      m.chat,
      {
        video: { url: play },
        caption: [
          "> *Tiktok Downloader* ☘️",
          `> *Judul:* ${title}`,
          `> *Author:* ${author?.nickname || "Tidak diketahui"}`,
          `> *Durasi:* ${duration} detik`,
        ].join("\n"),
      },
      { quoted: m },
    )

    // Kirim audio dengan stable conversion
    if (music_info?.play) {
      try {
        // Fetch audio buffer from URL
        const audioResponse = await fetch(music_info.play)
        const audioBuffer = await audioResponse.buffer()

        // Convert to WhatsApp voice note with waveform
        const { audio, waveform } = await toWhatsAppVoice(audioBuffer)

        await conn.sendMessage(
          m.chat,
          {
            audio: audio,
            waveform: waveform,
            mimetype: "audio/ogg; codecs=opus",
            fileName: `${music_info.title || "tiktok_audio"}.ogg`,
            ptt: false,
          },
          { quoted: m },
        )
      } catch (conversionError) {
        console.error("Stable conversion failed, using fallback:", conversionError)
        // Fallback to original method
        await conn.sendMessage(
          m.chat,
          {
            audio: { url: music_info.play },
            mimetype: "audio/mpeg",
            fileName: `${music_info.title || "tiktok_audio"}.mp3`,
            ptt: false,
          },
          { quoted: m },
        )
      }
    }

    await conn.sendMessage(m.chat, { react: { text: "✅", key: m.key } })
  } catch (err) {
    await conn.sendMessage(m.chat, { react: { text: "❌", key: m.key } })
    m.reply(`> Terjadi kesalahan:\n*${err.message}*`)
  }
}

handler.help = ["tiktok"]
handler.tags = ["downloader"]
handler.command = /^tiktok|tt$/i

module.exports = handler
