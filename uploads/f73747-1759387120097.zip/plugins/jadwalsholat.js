const axios = require('axios');

module.exports = {
    help: ['sholat <kota>'],
    tags: ['islamic'],
    command: ['sholat', 'salat'],
    limit: true,
    energy: 5,

    code: async (m, { conn, text, args, command }) => {
        const kota = args.join(' ') || text;
        if (!kota) return m.reply(`> Contoh:\n.${command} medan`);

        m.reply('🍃 Mengambil jadwal sholat...');

        try {
            const res = await jadwalsholat(kota);
            if (!res) return m.reply('> Kota tidak ditemukan atau data tidak tersedia.');

            await m.reply([
                `*🍃 Jadwal Sholat ${res.kota}* (${res.tanggal})`,
                ``,
                `*Subuh:* ${res.waktu.subuh}`,
                `*Dhuha:* ${res.waktu.dhuha}`,
                `*Dzuhur:* ${res.waktu.dzuhur}`,
                `*Ashar:* ${res.waktu.ashar}`,
                `*Maghrib:* ${res.waktu.maghrib}`,
                `*Isya:* ${res.waktu.isya}`
            ].join('\n'));
        } catch (err) {
            console.error("jadwalsholat error:", err);
            m.reply('> Terjadi kesalahan saat mengambil jadwal sholat.');
        }
    }
};

async function jadwalsholat(kota) {
    try {
        const { data } = await axios.get(`https://api.rijalganzz.my.id/islami/jadwalsholat?kota=${encodeURIComponent(kota)}`);
        if (data && data.status === true && data.result) {
            return data.result;
        }
        return null;
    } catch {
        return null;
    }
}
