const fs = require("fs");
const axios = require("axios");
const { ImageUploadService } = require("node-upload-images");

const handler = async (m, { conn, command }) => {
  let qmsg = m.quoted ? m.quoted : m;
  let mime = (qmsg.msg || qmsg).mimetype || "";

  if (!/image/.test(mime)) {
    return m.reply(
      `> Contoh penggunaan:\n> Balas atau kirim foto dengan caption *.${command}*`
    );
  }

  try {
    await conn.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });
    await m.reply("> Sedang mengubah gambar Anda menjadi *Action Figure...*");

    // Download media dari pesan
    let mediaPath = await conn.downloadAndSaveMediaMessage(qmsg);

    // Upload ke pixhost
    const service = new ImageUploadService("pixhost.to");
    let { directLink } = await service.uploadFromBinary(
      fs.readFileSync(mediaPath),
      "media.png"
    );

    fs.unlinkSync(mediaPath);

    // API request
    let apiUrl = `https://api-alipclutch.vercel.app/imagecreator/tofigure?apikey=alipclutch&url=${encodeURIComponent(
      directLink.toString()
    )}`;

    const response = await axios.get(apiUrl, { responseType: "arraybuffer" });

    await conn.sendMessage(
      m.chat,
      {
        image: response.data,
        caption: [
          "> *TO-FIGURE BERHASIL!*",
          "> Gambar berhasil diubah menjadi gaya action figure.",
        ].join("\n"),
      },
      { quoted: m }
    );

    await conn.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
  } catch (error) {
    console.error("Error di tofigure:", error);
    await conn.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
    m.reply(
      `> Terjadi kesalahan saat memproses:\n*${error.message || "Server API bermasalah."}*`
    );
  }
};

handler.help = ["tofigure"];
handler.tags = ["ai"];
handler.command = /^tofigure$/i;
handler.limit = 1;

module.exports = handler;