// > Creator: Danz
// > Plugin: ci-info.js

let handler = (m, { conn, text }) => {
    if (!text.includes('whatsapp.com')) throw '*[ ! ]* Mana link grup atau channel-nya untuk cek ID.';

    let link = new URL(text);

    return new Promise(async (resolve) => {
        const time = (ms) => {
            const date = new Date(ms * 1000);
            const hours = date.getHours().toString().padStart(2, '0');
            const minutes = date.getMinutes().toString().padStart(2, '0');
            const seconds = date.getSeconds().toString().padStart(2, '0');
            return `${hours}:${minutes}:${seconds}`;
        };

        let key;

        if (text.includes('https://whatsapp.com/channel/')) {
            key = link.pathname.split('/channel/')[1];

            await conn.newsletterMetadata('invite', key).then(async (ch) => {
                let caption = `> *Metadata Channel*
> *Nama:* ${ch.name || '-'}
> *Subscriber:* ${ch.subscribers || '-'}
> *Dibuat Pada:* ${await time(ch.creation_time) || '-'}
> *Viewer Metadata:* ${ch.viewer_metadata || '-'}
> *ID:* ${ch.id || '-'}`;

                await conn.sendMessage(m.chat, {
                    image: {
                        url: ch.preview || 'https://mmg.whatsapp.net' + ch.preview || ''
                    },
                    caption
                }, {
                    ephemeralExpiration: 86400,
                    quoted: m
                });
            });

        } else if (text.includes('https://chat.whatsapp.com')) {
            key = link.pathname.split('/')[1];

            await conn.groupGetInviteInfo(key).then(async (gc) => {
                let caption = `> *Metadata Grup*
> *Nama:* ${gc.subject || '-'}
> *Owner:* @${gc.owner?.split('@')[0] || '-'}
> *Dibuat Pada:* ${await time(gc.creation) || '-'}
> *Negara Owner:* ${gc.ownerCountry || '-'}
> *ID:* ${gc.id || '-'}`;

                await conn.sendMessage(m.chat, {
                    text: caption,
                    mentions: [gc.owner]
                }, {
                    ephemeralExpiration: 86400,
                    quoted: m
                });
            });

        } else {
            m.reply('*[ ! ]* Link tidak dikenali. Pastikan link adalah grup atau channel WhatsApp.');
        }
    });
};

handler.limit = true;

handler.help = ['ci', 'cekid'];
handler.command = ['ci', 'cekid'];
handler.tags = ['info'];

module.exports = handler;
