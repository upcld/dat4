// > Creator: Danz
// > Plugin: clearsesi-owner.js

const fs = require('node:fs');

module.exports = {
    command: ["delsesi", "clearsesi", "deletesesi"],
    help: ["delsesi", "clearsesi", "deletesesi"],
    tags: ["owner"],
    owner: true,

    async code(m, { conn }) {
        fs.readdir('./sessions', async (err, files) => {
            if (err) {
                console.log('Unable to scan directory: ' + err);
                return m.reply('*[ ! ]* Gagal memindai direktori.');
            }

            let filteredArray = files.filter(item =>
                item.startsWith('pre-key') ||
                item.startsWith('sender-key') ||
                item.startsWith('session-') ||
                item.startsWith('app-state')
            );

            if (filteredArray.length === 0) {
                return m.reply('> Tidak ada file session yang terdeteksi.');
            }

            let teks = `> Ditemukan *${filteredArray.length}* file session:\n\n`;
            filteredArray.forEach((e, i) => {
                teks += `${i + 1}. ${e}\n`;
            });

            await m.reply(teks);
            await sleep(2000);
            await m.reply('> Menghapus file session...');

            try {
                filteredArray.forEach(file => {
                    fs.unlinkSync(`./sessions/${file}`);
                });
            } catch (e) {
                console.error(e);
                return m.reply('*[ ! ]* Terjadi kesalahan saat menghapus file.');
            }

            await sleep(2000);
            await m.reply('> Semua file session berhasil dihapus.');
        });
    }
};

async function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}
