// > Creator: Danz
// > Plugin: getplugin.js
// > Fungsi: Mengambil isi file plugin dari folder ./plugins/ (mendukung .js dan .mjs)
// > Akses: Real Owner
// > Format: .getplugin namafile.js atau .getplugin namafile.mjs

const fs = require('fs');

let handler = async (m, { text }) => {
  if (!text) return m.reply('> ☘️ *Masukkan nama file plugin!*\nContoh: *.getplugin namafile.js* atau *.getplugin namafile.mjs*');
  if (!text.match(/\.(js|mjs)$/)) return m.reply('> ☘️ *Nama file harus berformat .js atau .mjs*');

  const filePath = `./plugins/${text.toLowerCase()}`;
  if (!fs.existsSync(filePath)) {
    return m.reply('> ☘️ *File plugin tidak ditemukan!*');
  }

  try {
    const fileContent = fs.readFileSync(filePath, 'utf-8');
    return m.reply(`> � Normalize: *Isi Plugin:*\n\n\`\`\`javascript\n${fileContent}\n\`\`\``);
  } catch (e) {
    console.error(e);
    return m.reply('> ☘️ *Gagal membaca file plugin!*');
  }
};

handler.command = ['getplugin', 'getp', 'gp', 'getplugins'];
handler.help = ['getplugin <namafile.js|namafile.mjs>'];
handler.tags = ['owner'];
handler.owner = true;

module.exports = handler;