const axios = require("axios");

const headers = {
  "Accept": "application/json, text/plain, */*",
  "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115 Safari/537.36",
  "Referer": "https://quran.kemenag.go.id/",
  "Origin": "https://quran.kemenag.go.id"
};

async function getListSurah() {
  const { data } = await axios.get("https://web-api.qurankemenag.net/quran-surah", { headers });
  return data.data.map(surah => ({
    nomor: surah.id,
    latin: surah.latin.trim(),
    arti: surah.translation,
    jumlah_ayat: surah.num_ayah
  }));
}

async function getAllAyat(surahInput) {
  const list = await getListSurah();
  const found = list.find(s =>
    s.latin.toLowerCase() === surahInput.toLowerCase() ||
    s.nomor === Number(surahInput)
  );
  if (!found) return { error: "Surah tidak ditemukan" };

  const { data } = await axios.get(
    `https://web-api.qurankemenag.net/quran-ayah?start=0&limit=${found.jumlah_ayat}&surah=${found.nomor}`,
    { headers }
  );

  return {
    surah: found.latin,
    arti_surah: found.arti,
    ayat: data.data.map(a => ({
      ayat: a.ayah,
      arab: a.arabic,
      latin: a.latin.trim(),
      terjemahan: a.translation
    }))
  };
}

module.exports = {
  help: ['surah <nama/nomor>'],
  tags: ['islami'],
  command: ['surah'],
  limit: true,
  energy: 5,

  code: async (m, { text, args }) => {
    if (!text) return m.reply('> Contoh: .surah 1\n> Contoh: .surah Al-Fatihah');
    try {
      const res = await getAllAyat(text);
      if (res.error) return m.reply('> Surah tidak ditemukan.');
      let out = [
        `*Surah:* ${res.surah}`,
        `*Arti:* ${res.arti_surah}`,
        ``,
        `*Ayat:*`
      ];
      res.ayat.forEach(a => {
        out.push(
          `(${a.ayat}) ${a.arab}\n${a.latin}\n${a.terjemahan}\n`
        );
      });
      m.reply(out.join('\n'));
    } catch (e) {
      console.error(e);
      m.reply('> Terjadi kesalahan saat mengambil data surah.');
    }
  }
};
