import axios from "axios"
import { ImageUploadService } from "node-upload-images"

const handler = async (m, { conn, text }) => {
  const qmsg = m.quoted ? m.quoted : m
  const mime = (qmsg.msg || qmsg).mimetype || ""

  if (!/image/.test(mime)) {
    return m.reply(`❌ Harap kirim atau balas sebuah gambar dengan caption:\n.fakeml "NAMA_KAMU"`)
  }

  const nickname = text ? text.trim() : (m.pushName || "User")
  m.reply("⏳ Sedang membuat Fake Lobby ML...")

  try {
    const mediaBuffer = await qmsg.download()
    if (!mediaBuffer) throw new Error("Gagal mengunduh gambar dari pesan.")

    const service = new ImageUploadService("pixhost.to")
    const { directLink } = await service.uploadFromBinary(mediaBuffer, "profile.png")
    const imageUrl = directLink.toString()

    const apiUrl = `https://api-alipclutch.vercel.app/imagecreator/fakeml?apikey=alipclutch&nama=${encodeURIComponent(
      nickname
    )}&url=${encodeURIComponent(imageUrl)}`

    const response = await axios.get(apiUrl, { responseType: "arraybuffer" })
    const outBuffer = Buffer.from(response.data)

    await conn.sendMessage(
      m.chat,
      { image: outBuffer, caption: `✅ *Sukses Membuat Fake Lobby ML*\n*Nickname:* ${nickname}` },
      { quoted: m }
    )
  } catch (e) {
    console.error(e)
    m.reply(`❌ Terjadi kesalahan saat membuat gambar:\n${e.message}`)
  }
}

handler.help = ["fakeml <nama>"]
handler.tags = ["fun", "tools", "ai"]
handler.command = /^fakeml$/i
handler.limit = 5

export default handler