const { downloadContentFromMessage } = require("@whiskeysockets/baileys");

let handler = async (m, { conn, args, participants }) => {
  let target;

  if (args[0]) {
    target = args[0].replace(/[^0-9]/g, '') + "@s.whatsapp.net";
  } else if (m.quoted) {
    target = m.quoted.sender;
  } else {
    target = m.sender;
  }

  try {
    const ppUrl = await conn.profilePictureUrl(target, "image");
    await conn.sendMessage(m.chat, { image: { url: ppUrl }, caption: `Foto profil @${target.split("@")[0]}` }, { quoted: m, mentions: [target] });
  } catch (e) {
    await m.reply("Tidak dapat mengambil foto profil.");
  }
};

handler.command = ["getpp"];
handler.help = ["getpp [nomor]"];
handler.tags = ["tools"];

module.exports = handler;
