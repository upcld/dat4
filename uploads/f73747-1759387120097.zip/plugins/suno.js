// 🎶 Plugin: suno.js
// 🤖 Creator: Kamu
// 📥 Fungsional: Generate lagu AI dari prompt menggunakan Suno API

const axios = require("axios")
const crypto = require("crypto")
const { toWhatsAppVoice } = require("../lib/audioConverter")

module.exports = {
  help: ["suno <prompt>"],
  tags: ["ai"],
  command: ["suno"],
  limit: true,
  limit: 10,
  code: async (m, { conn, text, command }) => {
    if (!text) {
      return m.reply(
        `> Contoh penggunaan:\\n> .${command} lagu tentang rasa cintaku kepada dia (perempuan), vokalis laki², nada lofi santai`,
      )
    }

    m.reply("> 🎶 Sedang membuat musik dari prompt... Mohon tunggu beberapa detik.")

    try {
      const result = await suno(text)

      if (!result?.data?.length) return m.reply("> Gagal mendapatkan hasil lagu dari Suno.")

      const audioUrl = result.data[0].audio_url
      const songTitle = result.data[0].title || "Suno Music"
      const lyrics = result.data[0].prompt || ""

      try {
        // Fetch audio buffer from URL
        const audioResponse = await axios.get(audioUrl, { responseType: "arraybuffer" })
        const audioBuffer = Buffer.from(audioResponse.data)

        // Convert to WhatsApp voice note with waveform
        const { audio, waveform } = await toWhatsAppVoice(audioBuffer)

        // Kirim lagu ke user dengan stable conversion
        await conn.sendMessage(
          m.chat,
          {
            audio: audio,
            waveform: waveform,
            mimetype: "audio/ogg; codecs=opus",
            fileName: `${songTitle}.ogg`,
            ptt: false,
          },
          { quoted: m },
        )
      } catch (conversionError) {
        console.error("Stable conversion failed, using fallback:", conversionError)
        // Fallback to original method
        await conn.sendMessage(
          m.chat,
          {
            audio: { url: audioUrl },
            mimetype: "audio/mpeg",
            fileName: `${songTitle}.mp3`,
            ptt: false,
          },
          { quoted: m },
        )
      }

      // Kirim lirik jika ada
      if (lyrics) {
        m.reply(`*🎵 Lirik Lagu: ${songTitle}*\\n\\n${lyrics}`)
      }
    } catch (e) {
      console.error(e)
      m.reply(`> Terjadi kesalahan:\\n*${e.message || e}*`)
    }
  },
}

// ====== 🔁 Fungsi utama pemanggil API Suno ======

async function suno(prompt, { style = "", title = "", instrumental = false } = {}) {
  if (!prompt) throw new Error("Prompt is required")
  if (typeof instrumental !== "boolean") throw new Error("Instrumental must be boolean")

  const { data: cf } = await axios.get("https://api.nekorinn.my.id/tools/rynn-stuff", {
    params: {
      mode: "turnstile-min",
      siteKey: "0x4AAAAAAAgeJUEUvYlF2CzO",
      url: "https://songgenerator.io/features/s-45",
      accessKey: "2c9247ce8044d5f87af608a244e10c94c5563b665e5f32a4bb2b2ad17613c1fc",
    },
  })

  const uid = crypto.createHash("md5").update(Date.now().toString()).digest("hex")

  const { data: task } = await axios.post(
    "https://aiarticle.erweima.ai/api/v1/secondary-page/api/create",
    {
      prompt,
      channel: "MUSIC",
      id: 1631,
      type: "features",
      source: "songgenerator.io",
      style,
      title,
      customMode: false,
      instrumental,
    },
    {
      headers: {
        uniqueid: uid,
        verify: cf.result.token,
      },
    },
  )

  while (true) {
    const { data } = await axios.get(`https://aiarticle.erweima.ai/api/v1/secondary-page/api/${task.data.recordId}`, {
      headers: {
        uniqueid: uid,
        verify: cf.result.token,
      },
    })

    if (data?.data?.state === "success") {
      try {
        const parsed = JSON.parse(data.data.completeData)
        return parsed
      } catch {
        return data.data.completeData
      }
    }

    await new Promise((res) => setTimeout(res, 1500))
  }
}
