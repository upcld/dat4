// Plugin: brat-sticker.mjs
// Creator: danz

import axios from 'axios';

let izuku = async (m, { conn, text }) => {
    if (!text) throw '*[ ! ]* Masukkan teks untuk membuat stiker.';

    try {
        const response = await axios.get('https://brat.siputzx.my.id/image', {
            params: { text },
            responseType: 'arraybuffer'
        });

        await conn.sendImageAsSticker(
            m.chat,
            response.data,
            m,
            {
                packname: 'Brat By:',
                author: config.name
            }
        );
    } catch (err) {
        m.reply('*[ ! ]* Terjadi kesalahan saat memproses permintaan.');
        console.error('Error:', err);
    }
};

izuku.limit = true;
izuku.loading = true;

izuku.help = ['brat', 'bratgenerator'];
izuku.command = /^(brat|bratgenerator)$/i;
izuku.tags = ['sticker'];

export default izuku;
