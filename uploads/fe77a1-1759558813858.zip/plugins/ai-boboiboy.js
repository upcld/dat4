// > Creator: Danz
// > Plugin: zchat.js
// > Fungsi: Mengirimkan pesan ke API z.ai untuk mendapatkan respons AI
// > Akses: Semua pengguna
// > Format: .zchat <pesan>

const axios = require('axios');

const apiKeys = [
  "204ce7cf74d1458eb27365fcad699124.myXalBaVNX1n5WbS",
  "a417b9ab1a0740dabd16e3d7e943c720.LBMLSMOOH6Q5ptKd",
  "ecc7090efb73490299d726ed80dc3168.PWkAFQcYnw4oja63",
  "80bc9518722849619d5aa22a036a6cca.aU02htYocDT9VANu",
  "7431d05bd592488ebb571e4b8be46ef1.gHFIqVMRsZdX5siX",
];

async function zChat(message, apiKey) {
  try {
    const { data } = await axios.post(
      'https://api.z.ai/api/paas/v4/chat/completions',
      {
        model: 'glm-4.5-flash',
        messages: [
          {
            role: 'system',
            content: 'Kamu adalah ai yang pintar bernama Boboiboy, jika berbicara kamu berlogat melayu atau oebih tepatnya berbahasa malaysia. Contoh nya aku menjadi saye',
          },
          {
            role: 'user',
            content: message,
          },
        ],
      },
      {
        headers: {
          'Content-Type': 'application/json',
          'Accept-Language': 'en-US,en',
          Authorization: `Bearer ${apiKey}`,
        },
      }
    );
    return data.choices[0].message.content;
  } catch (error) {
    throw new Error(error.response?.data?.message || error.message);
  }
}

let handler = async (m, { conn, text }) => {
  if (!text) return m.reply('> ☘️ *Masukkan prompt untuk AI!*\nContoh: *.boboiboy Halo, apa kabar?*');

  m.reply('> ☘️ *Sedang memproses pesan...*');

  let lastError = null;
  for (const apiKey of apiKeys) {
    try {
      const response = await zChat(text, apiKey);
      return m.reply(`> ☘️ *Respons AI:*\n\n${response}`);
    } catch (e) {
      lastError = e;
      console.error(`API Key ${apiKey} gagal: ${e.message}`);
      continue; // Coba API key berikutnya
    }
  }

  m.reply(`> ☘️ *Gagal mendapatkan respons dari AI!*\nError: ${lastError.message}`);
};

handler.command = ['boboiboy', 'boy'];
handler.help = ['boboyboy <pesan>'];
handler.tags = ['ai'];
handler.limit = true;

module.exports = handler;
