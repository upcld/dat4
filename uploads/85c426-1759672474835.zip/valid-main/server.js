// server.js
const express = require('express');
const cors = require('cors');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.static('.')); // Sajikan index.html, dll

// API: GET /number/list
app.get('/number/list', (req, res) => {
  try {
    const data = JSON.parse(fs.readFileSync(path.join(__dirname, 'number.json'), 'utf8'));
    res.json({
      success: true,
      count: data.numbers.length,
      numbers: data.numbers
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, error: 'Gagal memuat data' });
  }
});

// API: GET /number/validate/:number
app.get('/number/validate/:number', (req, res) => {
  const rawNumber = req.params.number;
  const cleanNumber = rawNumber.replace(/\D/g, '');

  try {
    const data = JSON.parse(fs.readFileSync(path.join(__dirname, 'number.json'), 'utf8'));
    const valid = data.numbers.includes(cleanNumber);
    res.json({ valid, number: cleanNumber });
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
});

// Jalankan server
app.listen(PORT, () => {
  console.log(`🟢 Server berjalan di http://localhost:${PORT}`);
  console.log(`📄 Buka: http://localhost:${PORT}`);
  console.log(`📡 API: http://localhost:${PORT}/number/list`);
});
