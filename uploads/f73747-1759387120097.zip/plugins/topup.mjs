import axios from "axios"

let handler = async (m, { text, command }) => {
  if (!text) {
    return m.reply(
      `Contoh:\n` +
      `.${command} <nama game> | <nama layanan> | <target_id>\n\n` +
      `Misal:\n.${command} Mobile Legends | 14 Diamonds (13 + 1 Bonus) | 98765`
    )
  }

  let [gameName, layananName, target_id] = text.split("|").map(s => s.trim())
  if (!gameName || !layananName || !target_id) {
    return m.reply(
      `Format salah!\n` +
      `.${command} <nama game> | <nama layanan> | <target_id>`
    )
  }

  m.reply("_*proses kak...*_")

  try {
    // ambil config dari global
    let api_id = global.maktopup_api_id
    let api_key = global.maktopup_api_key
    let signature = global.maktopup_signature

    // ambil daftar layanan
    let serviceRes = await axios.get("https://maktopup.com/api/service")
    let services = serviceRes.data.data

    if (!Array.isArray(services)) {
      return m.reply("*Gagal mendapatkan daftar layanan.*")
    }

    let layanan = services.find(s =>
      s.game.toLowerCase() === gameName.toLowerCase() &&
      s.nama_layanan.toLowerCase() === layananName.toLowerCase()
    )

    if (!layanan) {
      return m.reply("*Layanan tidak ditemukan, cek kembali nama game & layanan.*")
    }

    // buat pesanan
    let orderRes = await axios.post("https://maktopup.com/api/bot", {
      api_id,
      api_key,
      signature,
      service_id: layanan.id,
      target_id
    })

    let result = orderRes.data
    if (result.success) {
      let d = result.data
      await m.reply(
        `*Pesanan berhasil dibuat:*\n\n` +
        `Order ID: ${d.order_id}\n` +
        `Game: ${gameName}\n` +
        `Layanan: ${layanan.nama_layanan}\n` +
        `Target: ${d.target_id} (${d.target_name || "-"})\n` +
        `Harga: Rp ${d.harga}\n` +
        `Metode: ${d.method}\n\n` +
        `Checkout URL:\n${d.checkout_url}`
      )
    } else {
      m.reply("*Gagal membuat pesanan:* " + (result.message || "unknown error"))
    }
  } catch (err) {
    m.reply("*Terjadi kesalahan:* " + err.message)
  }
}

handler.command = /^topup$/i
handler.help = ["topup"]
handler.tags = ["store"]

export default handler
