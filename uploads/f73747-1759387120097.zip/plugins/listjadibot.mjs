import prettyms from 'pretty-ms'

let handler = async (m, { conn, command }) => {
  try {
    let userList = [...new Set([...global.conns.filter(c => c).map(c => c)])]
    let text = "*List Jadibot*\n\n"
    text += ` Total : ${global.conns.length}\n\n`

    for (let u of userList) {
      let jid = u.user?.id || ""
      let name = u.user?.name || "-"
      let id = jid.split("@")[0]
      let uptime = prettyms(Date.now() - (u.time || Date.now()), { verbose: true })

      text += ` × User : @${id}\n`
      text += ` × Name : ${name}\n`
      text += ` × Uptime : ${uptime}\n\n`
    }

    if (userList.length > 0) {
      await m.reply(text, { withTag: true })
    } else {
      await m.reply("_*Tidak ada user yang menumpang..*_")
    }
  } catch (e) {
    if (typeof global.error === "function") {
      global.error(command, e, m)
    } else {
      m.reply("*Terjadi kesalahan:* " + e.message)
    }
  }
}

handler.command = /^listjadibot|listbot$/i
handler.help = ["listjadibot", "listbot"]
handler.tags = ["jadibot"]
handler.private = true

export default handler