import fetch from 'node-fetch'

let handler = async (m, { conn }) => {
  try {
    // Ambil foto profil grup atau chat
    let pp = await conn.profilePictureUrl(m.chat, 'image').catch(_ => null)
    let pepe = pp ? await (await fetch(pp)).buffer() : Buffer.alloc(0)

    let str = `> ${conn.getName(m.sender)} ingin support bot?

*PAYMENT ↓*
*Pulsa (Three)* : 0895323195263
*Dana* : 082179230256

> Setelah melakukan donasi, kirim bukti pembayaran ke owner.
> Dengan donasi, kamu sudah membantu bot ini agar tetap *online 24 jam* dan *fast respon*.

📌 Github: https://github.com/wirdan1/
`

    await conn.sendMessage(m.chat, {
      image: pepe,
      caption: str
    }, { quoted: m })

  } catch (e) {
    m.reply(`❌ Terjadi kesalahan: ${e.message}`)
  }
}

handler.help = ['donasi']
handler.tags = ['info']
handler.command = /^dona(te|si)$/i

export default handler
