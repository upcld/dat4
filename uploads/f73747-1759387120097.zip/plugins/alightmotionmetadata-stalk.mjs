// Plugin: alightmotionmetadata-stalk.mjs
// Creator: danz

/**
 * Scrape metadata dari Alight Motion preset link
 * Base URL: https://play.google.com/store/apps/details?id=com.alightcreative.motion
 */

import axios from 'axios';

let izuku = async (m, { conn, text }) => {
    if (!text.includes('alight')) throw '*[ ! ]* Link tidak valid atau belum diberikan.';
    
    try {
        const response = await amdata(text);
        let caption = 
`> *Alight Motion Metadata*
> _Judul_: ${response.info.projects.map(a => a.title).join(', ') || '-'}
> _Ukuran_: ${response.info.projects.map(a => a.size).join(', ') || '-'}
> _Total Unduhan_: ${response.info.downloads || '-'}
> _Tautan Unduh_: ${response.download || '-'}
> _Versi Alight Motion_: ${response.info.amPackageVersion || '-'}`;

        const image = await axios.get(response.info.largeThumbUrl, {
            responseType: 'arraybuffer'
        });

        conn.reply(m.chat, image.data, m, { caption });
    } catch (e) {
        m.reply('*[ ! ]* Terjadi kesalahan. Silakan coba lagi nanti.');
        console.error('Error:', e);
    }
};

async function amdata(url) {
    try {
        const match = url.match(/\/u\/([^\/]+)\/p\/([^\/\?#]+)/);
        if (!match) throw new Error('URL tidak valid');
        
        const { data } = await axios.post(
            'https://us-central1-alight-creative.cloudfunctions.net/getProjectMetadata',
            {
                data: {
                    uid: match[1],
                    pid: match[2],
                    platform: 'android',
                    appBuild: 1002592,
                    acctTestMode: 'normal'
                }
            },
            {
                headers: {
                    'content-type': 'application/json; charset=utf-8'
                }
            }
        );

        return data.result;
    } catch (error) {
        throw new Error(error.message);
    }
};

izuku.limit = true;
izuku.help = ['am-metadata', 'alightmotion-metadata'];
izuku.command = ['am-metadata', 'alightmotion-metadata'];

export default izuku;
