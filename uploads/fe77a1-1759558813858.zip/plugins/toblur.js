const Jimp = require('jimp')

module.exports = {
  help: ['toblur <angka>'],
  tags: ['tools'],
  command: ['toblur'],
  limit: true,

  code: async (m, { conn, args }) => {
    const q = m.quoted ? m.quoted : m
    const mime = (q.msg || q).mimetype || ''

    if (!mime.startsWith('image/')) return m.reply('Kirim/quote gambar untuk diblur 🍃')

    let blurLevel = parseInt(args[0]) || 5
    if (blurLevel < 1) blurLevel = 1
    if (blurLevel > 100) blurLevel = 100

    m.reply(`Sedang memproses blur level ${blurLevel}... 🍃`)
    const media = await q.download()

    try {
      const image = await Jimp.read(media)
      image.blur(blurLevel)
      const buffer = await image.getBufferAsync(Jimp.MIME_JPEG)

      await conn.sendMessage(
        m.chat,
        { image: buffer, caption: `Gambar berhasil diblur (level ${blurLevel}) 🍃` },
        { quoted: m }
      )
    } catch (e) {
      m.reply('Terjadi kesalahan: ' + e.message)
    }
  }
}
