let handler = async (m, { conn, command, text }) => {
  // Opsional: validasi jika ingin batasi ke nomor tertentu (misal admin)
  // Tapi secara default, siapa pun yang kirim perintah bisa jadi jadibot

  try {
    // Validasi: pastikan hanya private chat
    if (!m.chat.endsWith('@s.whatsapp.net')) {
      return m.reply('Perintah ini hanya bisa digunakan di chat pribadi.')
    }

    let { jadibot } = await import("../lib/jadibot.js")
    await jadibot(m, conn)
  } catch (e) {
    if (typeof global.error === "function") {
      global.error(command, e, m)
    } else {
      m.reply("*Terjadi kesalahan:* " + (e.message || e))
    }
  }
}

handler.command = /^jadibot$/i
handler.help = ["jadibot"]
handler.tags = ["jadibot"]
handler.private = true

export default handler